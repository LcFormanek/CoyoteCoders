############## Imports #################

from flask import Flask, render_template, redirect, request, url_for, g, session, flash, abort 
from flask_bootstrap import Bootstrap
from yahoo_finance import Share 
from wtforms import Form, BooleanField, TextField, PasswordField, validators
from functools import wraps
from flask_sqlalchemy import SQLAlchemy
from flask.ext.login import LoginManager, login_user, logout_user, current_user, login_required
import decimal
import random 
import locale 
import psycopg2
locale.setlocale(locale.LC_ALL, '')

############ Boilerplate ###################

app = Flask(__name__)
app.debug = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgres://mpitamfbhcsmja:gmF2tie09IpIjMmgbsbNIbCUnG@ec2-54-235-90-96.compute-1.amazonaws.com:5432/dfpuh4prt1ju8t' 
db = SQLAlchemy(app)
Bootstrap(app)
app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

############ DB Table Models #############################

class User(db.Model):
    __tablename__ =  'user'
    id = db.Column('id', db.Integer, primary_key = True, autoincrement=1) 
    username = db.Column('username', db.String(20), unique=True) 
    password = db.Column('password', db.String(100))

    def __init__(self , username, password):
        #self.id = User.query.count() + 1
        self.username = username
        self.password = password
    
    def is_authenticated(self):
        return True
    
    def is_active(self):
        return True
    
    def is_anonymous(self):
        return False
    
    def get_id(self):
        return str(self.id)
        
    def __repr__(self):
        return '<User %r>' % self.username

class Owned(db.Model):
    __tablename__ = 'owned'
    id = db.Column('id', db.Integer, primary_key = True, autoincrement=1)
    uid = db.Column(db.Integer)
    symbol = db.Column(db.String(6))
    basis = db.Column(db.Float)
    shares = db.Column(db.Float) 
        
    def __init__(self, uid, symbol, basis, shares):
        #self.id = Owned.query.count() + 1
        self.uid = uid
        self.symbol = symbol.upper()
        self.basis = basis
        self.shares = shares 
        
    def __repr__(self):
        return '<symbol: %r>' % self.symbol
	
	
class Watchlist(db.Model):
    __tablename__ = 'watchlist'
    id = db.Column('id', db.Integer, primary_key = True, autoincrement=1)
    uid = db.Column(db.Integer)
    symbol = db.Column(db.String(6))
    
    def __init__(self, uid, symbol):
        #self.id = Watchlist.query.count() + 1
        self.uid = uid
        self.symbol = symbol.upper()
        

db.create_all() 

############## WTForms Classes #######################
	
class AddOwned(Form):
	symbol = TextField('Ticker:', [validators.InputRequired(message=None)])
	basis = TextField('Basis (per share):', [validators.InputRequired(message=None)])
	shares = TextField('Shares Owned:', [validators.InputRequired(message=None)])
    

    
class AddWatchlistItem(Form):
    symbol = TextField('Ticker:', [validators.InputRequired(message=None)])
    
class Login(Form):
    username = TextField('Username:', [validators.InputRequired(message=None)])
    password = PasswordField('Password:', [validators.InputRequired(message=None)])
    
class Register(Form):
    username = username = TextField('Username:', [validators.InputRequired(message=None)])
    password = PasswordField('Password:', [validators.InputRequired(message=None)])
    confirm_password = PasswordField('Confirm Password:', [validators.InputRequired(message=None)])
    
############# Functions #################

def dollars(arg):
    try: 
        arg = float(arg) 
        return str(locale.currency(arg, symbol=True, grouping=True))
    except:
        return "None" 


def percent(arg):
    arg = round(float(arg), 2)
    return str(arg) + "%"
    
##### Back End Decorators #####
    
@app.before_request
def before_request():
    g.user = current_user
    #print(current_user.id) 

    
@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))
    
    
##### Route Decorators #####

    #////////////// Navigation /////////////////#

@app.route('/')
@app.route('/index')
@login_required
def index():
    total_return = 0 
    success = request.args.get('success')
    failed = request.args.get('failed')
    stock_name = request.args.get('stock_name')
    deleted = request.args.get('deleted')
    deleted_list = request.args.get('deleted_list')
    form = AddOwned(request.form)
    cid = current_user.id 
    all = Owned.query.filter_by(uid=cid).all()  
    columns = ["", "Symbol", "Quantity", "Basis", "Current Price", "Gain/Share", "Total Gain/Loss", "Day's Change", "Dividend", "Dividend Yield", "Market Cap"]
    
    passlist = []
    
    for item in all:
        id = item.id 
        symbol = item.symbol
        pass_symbol = symbol
        symbol = Share(symbol)
        change = symbol.get_change()
        shares = item.shares
        cap = symbol.get_market_cap()
        basis = item.basis
        current_price = symbol.get_price()
        dividend = symbol.get_dividend_yield()
        if dividend == None:
            dividend = "None"
        else:
            dividend = dollars(dividend) 
        dividend_yield = symbol.get_dividend_yield()
        if dividend_yield == None:
            dividend_yield = "None"
        else:
            dividend_yield = percent(dividend_yield) 
        gain_per_share = float(current_price) - float(basis)
        total_gain = gain_per_share * shares 
        total_return += total_gain 
        li = [id, str(pass_symbol), str(round(shares, 4)), dollars(basis), dollars(current_price), dollars(gain_per_share), dollars(total_gain), dollars(change), dividend, dividend_yield, str(cap)]
        passlist.append(li) 
    total_return = dollars(total_return)
    return render_template('index.html', form=form, passlist=passlist, columns=columns, success=success, failed=failed, stock_name=stock_name, deleted=deleted, deleted_list=deleted_list, total_return=total_return)

@app.route('/watchlist')
@login_required
def watchlist():
    success = request.args.get('success')
    failed = request.args.get('failed')
    stock_name = request.args.get('stock_name')
    deleted = request.args.get('deleted')
    deleted_list = request.args.get('deleted_list')
    form = AddWatchlistItem(request.form)
    cid = current_user.id 
    all = Watchlist.query.filter_by(uid=cid).all()  
    columns = ["", "Symbol", "Current Price", "Day's Change", "Day's High", "Day's Low", "52-Week High", "52-Week Low", "Dividend", "Dividend Yield", "Market Cap"]
    
    passlist = [] 
    
    
    for item in all:
        id = item.id 
        symbol = item.symbol
        pass_symbol = symbol
        symbol = Share(symbol)
        change = symbol.get_change()
        day_high = symbol.get_days_high()
        day_low = symbol.get_days_low()
        yr_high = symbol.get_year_high()
        yr_low = symbol.get_year_low()
        cap = symbol.get_market_cap()
        current_price = symbol.get_price()
        dividend_yield = symbol.get_dividend_yield()
        if dividend_yield == None:
            dividend_yield = "None"
        else:
            dividend_yield = percent(dividend_yield) 
            
        dividend = symbol.get_dividend_share()
        if dividend == None:
            dividend = "None"
        else:
            dividend = dollars(dividend) 
        li = [id, str(pass_symbol), dollars(current_price), dollars(change), dollars(day_high), dollars(day_low), dollars(yr_high), dollars(yr_low),  dividend, dividend_yield, str(cap)]
        passlist.append(li) 
    
    return render_template('watchlist.html', form=form, passlist=passlist, columns=columns, success=success, failed=failed, stock_name=stock_name, deleted=deleted, deleted_list=deleted_list)
    
    
@app.route('/account')
@login_required
def account():
    return render_template('account.html')
    

@app.route('/about')
def about():
    return render_template('about.html')
    
    
@app.route('/market')
@login_required
def market():
    return render_template('market.html')
    
    
    #///////////// Data Management ///////////////////////
    
@app.route('/add_owned', methods=['GET', 'POST'])
@login_required
def add_owned():
    success = None 
    failed = None 
    form = AddOwned(request.form) 
    stock_name = form.symbol.data
    if request.method == 'POST':
    
        try:
            if form.symbol.data != None and float(form.basis.data) > 0 and float(form.shares.data) > 0:
                test = Share(form.symbol.data)
                test = test.get_price()
                if test != None:
                    new = Owned(current_user.id, form.symbol.data.upper(), form.basis.data, form.shares.data) 
                    db.session.add(new) 
                    db.session.commit()
                    success = True
                    failed = False
                else:
                    failed = "symbol_error"
        except:
            failed = "form_error"
        
        return redirect(url_for('index', success=success, stock_name=stock_name.upper(), failed=failed))

@app.route('/add_watching', methods=['GET', 'POST'])
@login_required
def add_watching():
    success = None
    failed = None
    form = AddOwned(request.form)
    stock_name = form.symbol.data 
    if request.method == 'POST':
        try:
            test = Share(form.symbol.data)
            test = test.get_price()
            if test != None:
                new = Watchlist(current_user.id, form.symbol.data) 
                db.session.add(new) 
                db.session.commit()
                success = True
                failed = False
            else:
                failed = "symbol_error"
        except:
            failed = "form_error"
            
    return redirect(url_for('watchlist', success=success, failed=failed, stock_name=stock_name.upper()))

@app.route('/delete_owned', methods=['GET', 'POST'])  
@login_required
def delete_owned():
    deleted = True
    owned_ids = request.form.getlist("delete")
    print(owned_ids)
    to_delete = db.session.query(Owned).filter((Owned.uid==current_user.id) and Owned.id.in_(owned_ids)).all()
    deleted_list = []
    for item in to_delete:
        print("ids: ", item.id)
        if str(item.id) in owned_ids:
            print("deleting correctly") 
            db.session.delete(item) 
            db.session.commit()
    
    return redirect(url_for('index', deleted=deleted, deleted_list=deleted_list))
    
@app.route('/delete_watching', methods=['GET', 'POST'])  
@login_required
def delete_watching():
    deleted = True
    watchlist_ids = request.form.getlist("delete")
    print(watchlist_ids)
    to_delete = db.session.query(Watchlist).filter(Watchlist.uid==current_user.id).all()
    deleted_list = []
    print(deleted_list)
    for item in to_delete:
        print("ids: ", item.id)
        if str(item.id) in watchlist_ids:
            print("deleting correctly") 
            db.session.delete(item) 
            db.session.commit()
            deleted_list.append(str(item.symbol))
            print(deleted_list)
            
    
    return redirect(url_for('watchlist', deleted=deleted, deleted_list=deleted_list))
    
    #////////////// User Management /////////////////#
	
@app.route('/register' , methods=['GET','POST'])
def register():
    form = Register(request.form)
    valid_registration = request.args.get('valid_registration')
    if request.method == 'GET':
        return render_template('register.html', form=form, valid_registration=valid_registration)
    if form.password.data == form.confirm_password.data:
        users = db.session.query(User).all()
        user_check = []
        for user in users:
            user_check.append(user.username) 
        print(user_check)
        print('username:', form.username.data) 
        if form.username.data not in user_check:
            user = User(form.username.data, form.password.data)
            db.session.add(user)
            db.session.commit()
            flash('User successfully registered')
            valid_registration = True
            return redirect(url_for('login', valid_registration=valid_registration))
        valid_registration = "exists"
        return redirect(url_for('register', valid_registration=valid_registration))
    valid_registration = "password" 
    return redirect(url_for('register', valid_registration=valid_registration))

@app.route('/login', methods=['GET','POST'])
def login(*args):
    valid_registration=request.args.get('valid_registration')
    form = Login(request.form)
    if request.method == 'GET':
        if 'error' in locals():
            print(error) 
            return render_template('login.html', error=error, form=form) 
        error = False 
        return render_template('login.html', form=form, valid_registration=valid_registration)
    username = form.username.data
    password = form.password.data
    print(User.query.filter_by(username=username, password=password).all())
    registered_user = User.query.filter_by(username=username, password=password).first()
    if registered_user is None:
        print("here")
        flash('Username or Password is invalid' , 'error')
        error = True 
        return render_template('/login.html', error=error, form=form)
    
    login_user(registered_user)
    flash('Logged in successfully')
    return redirect(request.args.get('next') or url_for('index'))
    
@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index')) 
    
######## App Startup ###########

if __name__ == '__main__':
	app.run()
    

# delete user
# .csv export  
   
    
    
    